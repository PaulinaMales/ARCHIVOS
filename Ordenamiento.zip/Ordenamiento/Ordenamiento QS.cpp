#include <iostream>
#include "Ordenamiento QS.h"
//#define TAM 50
using namespace std;

void ingresar(int a[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Ingrese elemento #" << i + 1 << ": ";
        cin >> a[i];
    }

    cout << "Los numeros son: \n";
    for (int i = 0; i < n; i++)
    {
        cout << "[" << a[i] << "]"
             << "\t";
    }
    cout << "\nElementos ordenados" << endl;
    ordenar(a, 0, n - 1);
    for (int i = 0; i < n; i++)
    {
        cout << "[" << a[i] << "]";
    }
}

int mitad(int a[], int pinicial, int pfinal)
{
    return a[(pinicial + pfinal) / 2];
}
void ordenar(int a[], int pinicial, int pfinal)
{

    int i = pinicial;
    int j = pfinal;
    int temp;
    int piv = mitad(a, pinicial, pfinal);

    do
    {
        while (a[i] < piv)
        {
            i++;
        }
        while (a[j] > piv)
        {
            j--;
        }
        if (i <= j)
        {
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            i++;
            j--;
        }
    } while (i <= j);
    if (pinicial < j)
    {
        ordenar(a, pinicial, j);
    }
    if (i < pfinal)
    {
        ordenar(a, i, pfinal);
    }
}