#include <iostream> 
#include "Ordenamiento QS.h" 
 #define TAM 50
 
 using namespace std;
 
int main()
{
    int n;
    cout << "Cuantos elementos desea ingresar?: ";
    cin >> n;
    int a[n];
    ingresar( a, n);
    
    return 0;

}

/*int main(){
 	int a[TAM],n;
 		
   ingresar( a, n);
   cout<<"\nElementos ordenados"<<endl;
   
   El error que te salía en un inicio es porque como la función ordenamiento está fuera de la función ingresar,
   por ende la función ordenmaineto estaba tomando datos basura y no podía terminar el proceso. Recuerda que 
   siempre debe estar el algoritmo de ordenamiento dentro de donde estés pidiendo los datos ya que de esa forma sabe que tiene que ordenar. 
   
   ordenar(a,0,n-1);
    for(int i=0;i<n;i++)
        {
            cout<<"["<<a[i]<<"]";
        }
 return 0; 
 }

COMENTARIOS Y MODIFICACIONES
   1.- Dentro del archivo .h solo debes incluir las funciones nada más, ni librerías, ni variables , ni constantes.
   2.- Para que te funcione el programa siempre tiene que revisar que en el archivo se encuentre la carpeta .vscode donde
   se encuentrar los archivos .json y dentro del tasks.json debes incluir el archivo donde se encuentran todas las funciones 
   detalladas siempre es el archivo .pp, en este caso "Ordenamiento QS.cpp" entre comillas despues de "${file}" y seguido de una coma
   3.- Bueno esto si estaba pero por si acaso siempre debes incluir la librería .h dentro de los dos archivos .cpp para que pueda funcionar.*/

