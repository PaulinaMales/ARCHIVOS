//Dentro del archivo .h solo debe ir las funciones no debes incluir nada más.
/*#include <iostream> 
 #define TAM 50
 using namespace std;*/
 
void ingresar(int a[], int n);
int mitad (int a[],int pinicial, int pfinal);
void ordenar (int a[],int pinicial, int pfinal);

